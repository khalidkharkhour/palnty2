/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1687523872_wp_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1687523872_wp_terms` ( `term_id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `term_group` bigint NOT NULL DEFAULT '0', PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1687523872_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Non classé','non-classe',0),(4,'palnty','palnty',0),(5,'simple','simple',0),(6,'grouped','grouped',0),(7,'variable','variable',0),(8,'external','external',0),(9,'exclude-from-search','exclude-from-search',0),(10,'exclude-from-catalog','exclude-from-catalog',0),(11,'featured','featured',0),(12,'outofstock','outofstock',0),(13,'rated-1','rated-1',0),(14,'rated-2','rated-2',0),(15,'rated-3','rated-3',0),(16,'rated-4','rated-4',0),(17,'rated-5','rated-5',0),(18,'Uncategorized','uncategorized',0);
