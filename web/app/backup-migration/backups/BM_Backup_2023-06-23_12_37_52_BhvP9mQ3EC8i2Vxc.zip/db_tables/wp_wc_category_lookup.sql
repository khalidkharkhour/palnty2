/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_category_lookup`; */
/* PRE_TABLE_NAME: `1687523872_wp_wc_category_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1687523872_wp_wc_category_lookup` ( `category_tree_id` bigint unsigned NOT NULL, `category_id` bigint unsigned NOT NULL, PRIMARY KEY (`category_tree_id`,`category_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1687523872_wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES (18,18);
