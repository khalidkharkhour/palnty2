/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `commandes`; */
/* PRE_TABLE_NAME: `1687523872_commandes`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1687523872_commandes` ( `id` int NOT NULL AUTO_INCREMENT, `boisson` varchar(50) NOT NULL, `nom` varchar(50) NOT NULL, `prenom` varchar(50) NOT NULL, `email` varchar(100) NOT NULL, `livraison` tinyint(1) NOT NULL, `adresse_livraison` varchar(100) DEFAULT NULL, `code_postal` varchar(10) DEFAULT NULL, `ville` varchar(50) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `1687523872_commandes` (`id`, `boisson`, `nom`, `prenom`, `email`, `livraison`, `adresse_livraison`, `code_postal`, `ville`) VALUES (1,'FRAISE','Nom Client','Prénom Client','client@example.com',1,'Adresse de livraison',12345,'Ville');
