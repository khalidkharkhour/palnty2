/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1687523872_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1687523872_wp_wpforms_tasks_meta` ( `id` bigint NOT NULL AUTO_INCREMENT, `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL, `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1687523872_wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES (1,'wpforms_process_forms_locator_scan','W10=','2023-06-08 09:47:27'),(2,'wpforms_admin_addons_cache_update','W10=','2023-06-08 09:47:29'),(4,'wpforms_builder_help_cache_update','W10=','2023-06-08 09:47:49'),(5,'wpforms_admin_builder_templates_cache_update','W10=','2023-06-08 09:47:49');
