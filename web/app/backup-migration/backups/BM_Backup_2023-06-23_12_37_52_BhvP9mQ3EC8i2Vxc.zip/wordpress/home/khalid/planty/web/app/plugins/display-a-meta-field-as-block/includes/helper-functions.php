<?php
/**
 * Helper functions
 *
 * @package   MetaFieldBlock
 * @author    Phi Phan <mrphipv@gmail.com>
 * @copyright Copyright (c) 2023, Phi Phan
 */

namespace MetaFieldBlock;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( __NAMESPACE__ . '\meta_field_block_get_block_markup' ) ) :
	/**
	 * Build block markup.
	 *
	 * @param  string     $content    Block content.
	 * @param  array      $attributes Block attributes.
	 * @param  WP_Block   $block      Block instance.
	 * @param  int|string $post_id    Post Id.
	 * @param  string     $classes    Additional block classes.
	 *
	 * @return string Returns the markup for the block.
	 */
	function meta_field_block_get_block_markup( $content, $attributes, $block, $post_id, $classes = '' ) {
		// Allow third-party plugins to alter the content.
		$content = apply_filters( 'meta_field_block_get_block_content', $content, $attributes, $block, $post_id );
		$content = is_array( $content ) || is_object( $content ) ? '<code><em>' . __( 'This data type is not supported!', 'display-a-meta-field-as-block' ) . '</em></code>' : $content;

		if ( '' === trim( $content ) ) {
			// Hide the block.
			if ( $attributes['hideEmpty'] ?? false ) {
				return '';
			}

			$empty_message = $attributes['emptyMessage'] ?? '';
			if ( $empty_message ) {
				$content = $empty_message;
			}
		}

		$tag_name  = $attributes['tagName'] ?? 'div';
		$inner_tag = 'div' === $tag_name ? 'div' : 'span';

		// Escape content and wrap around a div.
		$content = sprintf( '<%2$s class="value">%1$s</%2$s>', wp_kses( $content, wp_kses_allowed_html( 'post' ) ), $inner_tag );

		$prefix = $attributes['prefix'] ?? '';

		if ( ! $prefix && ( $attributes['labelAsPrefix'] ?? false ) ) {
			$prefix = meta_field_block_get_field_label( $attributes, $post_id );
		}
		$prefix = $prefix ? sprintf( '<%2$s class="prefix">%1$s</%2$s>', wp_kses( $prefix, wp_kses_allowed_html( 'post' ) ), $inner_tag ) : '';

		$suffix = $attributes['suffix'] ?? '';
		$suffix = $suffix ? sprintf( '<%2$s class="suffix">%1$s</%2$s>', wp_kses( $suffix, wp_kses_allowed_html( 'post' ) ), $inner_tag ) : '';

		if ( ! empty( $attributes['displayLayout'] ) ) {
			$classes .= " is-display-{$attributes['displayLayout']}";
		}
		if ( isset( $attributes['textAlign'] ) ) {
			$classes .= " has-text-align-{$attributes['textAlign']}";
		}
		$wrapper_attributes = get_block_wrapper_attributes( array( 'class' => trim( $classes ) ) );

		return sprintf( '<%3$s %1$s>%2$s</%3$s>', $wrapper_attributes, $prefix . $content . $suffix, $tag_name );
	}
endif;

if ( ! function_exists( __NAMESPACE__ . '\meta_field_block_get_field_label' ) ) :
	/**
	 * Get field label.
	 *
	 * @param  array      $attributes Block attributes.
	 * @param  int|string $post_id    Post Id.
	 *
	 * @return string Returns the field label.
	 */
	function meta_field_block_get_field_label( $attributes, $post_id ) {
		$field_label = '';

		$field_type = $attributes['fieldType'] ?? 'meta';
		$field_name = $attributes['fieldName'] ?? '';

		if ( 'acf' === $field_type && \function_exists( 'get_field_object' ) ) {
			$field = get_field_object( $field_name, $post_id );

			if ( $field ) {
				$field_label = $field['label'] ?? '';
			}
		}

		return $field_label;
	}
endif;
