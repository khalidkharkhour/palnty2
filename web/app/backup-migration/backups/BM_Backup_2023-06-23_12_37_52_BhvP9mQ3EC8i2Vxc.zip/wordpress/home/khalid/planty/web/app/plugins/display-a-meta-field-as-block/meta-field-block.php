<?php
/**
 * Plugin Name:       Meta Field Block
 * Description:       Display a meta field or a custom field as a block on the front end, supporting ACF fields.
 * Requires at least: 5.8
 * Requires PHP:      7.0
 * Version:           1.1.4
 * Author:            Phi Phan
 * Author URI:        https://boldblocks.net
 *
 * @package   MetaFieldBlock
 * @copyright Copyright(c) 2022, Phi Phan
 */

namespace MetaFieldBlock;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! defined( 'MFB_ROOT_FILE' ) ) {
	define( 'MFB_ROOT_FILE', __FILE__ );
}

// Helper functions
require_once __DIR__ . '/includes/helper-functions.php';

// REST fields.
require_once __DIR__ . '/includes/rest-fields.php';

// Load ACF required files.
require_once __DIR__ . '/includes/acf.php';

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
function meta_field_block_init() {
	register_block_type( __DIR__ . '/build', [ 'render_callback' => __NAMESPACE__ . '\\meta_field_block_render_block' ] );
}
add_action( 'init', __NAMESPACE__ . '\\meta_field_block_init' );

/**
 * Renders the `mbf/meta-field-block` block on the server.
 *
 * @param  array    $attributes Block attributes.
 * @param  string   $content    Block default content.
 * @param  WP_Block $block      Block instance.
 * @return string Returns the filtered post meta field for the current post.
 */
function meta_field_block_render_block( $attributes, $content, $block ) {
	if ( isset( $block->context['postId'] ) ) {
		// Get post_id from the context first.
		$post_id = $block->context['postId'];
	} else {
		// Fallback to the current post id.
		$post_id = get_queried_object_id();
	}

	$field_type = $attributes['fieldType'] ?? 'rest_field';
	$field_name = $attributes['fieldName'] ?? '';
	if ( empty( $field_name ) ) {
		return '';
	}

	$content = '';
	if ( 'acf' === $field_type ) {
		if ( function_exists( 'get_field_object' ) ) {
			$content = MFBACFFields::get_instance()->get_field_value( $field_name, $post_id );
		} else {
			$content = '<code><em>' . __( 'This data type requires the ACF plugin installed and activated!', 'display-a-meta-field-as-block' ) . '</em></code>';
		}
	} else {
		$content = get_post_meta( $post_id, $field_name, true );
	}

	// Additional block classes.
	$classes = "is-{$field_type}-field";

	// Get the block markup.
	return meta_field_block_get_block_markup( $content, $attributes, $block, $post_id, $classes );
}
